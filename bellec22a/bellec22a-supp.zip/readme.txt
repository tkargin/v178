Simulation code:

The code contains five python files: 

Expe7132.py: Provide Base class `Expe7132` to run Huber Elastic Net simulation.
Expe6585.py: Provide Derived class `Expe6585` to generate boxplots.
Expe2947.py: Provide Derived class `Expe2947` to generate tables, histplots and qqplots.
Expe9591.py: Provide Derived class `Expe9591` to generate heatmaps with lambda_star = 0.054.
Expe9592.py: Provide Derived class `Expe9592` to generate heatmaps with lambda_star = 0.024.
Remark: (update) To generate extra heatmaps, mentioned in the author response to the reviews, the heatmaps comparing ALO, our criterion, and our criterion with unobservable trace[SigmaA], run python file ./compare_alo_lo/heatmap_setup_3.py. This shall generate heatmaps in folder ./compare_alo_lo/fig3/


Inside the folder non-gaussian-design, we have almost the same five python files, while the Expe7132.py file in the folder non-gaussian-design uses Rademacher design matrix with entries +1 or -1 with probability 0.5 to generate the data.

How to use:

Each experiment class provides a `do_more` method to generate simulation results with a bool argument `to_generate`. The bool argument `to_generate` controls whether we plot the figures using the local dumped data, or we generate new data and then plot figures.

In command line, "python3 Expe6585.py" shall generate the results (You need to check before whether `to_generate` is set to the value you need. If you need to generate new datasets, change `to_generate` to be `True` in the python file and run the `do_more` method.)

Depending on the experiment you perform and the `num_iter` value, it can be 40 hours - 80 hours to generate all the dataset with the default parameters provided in the code files.

We are running our code under the following environment:

- Ubuntu 20.04
- Python 3.8.5 with packages:
    numpy, sklearn, pandas, statsmodels, seaborn, matplotlib, scipy, warnings, tabulate, rich, pickle, os, collections.
