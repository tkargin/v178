"""
Provides the elastic-net estimator, the crit and the ALO.
"""
from sklearn.linear_model import (
        ElasticNet,
        enet_path,
        )
from abstract_regression import AbstractRegression
from numpy import (
        nonzero,
        trace,
        eye,
        diag,
        ones,
        outer,
        apply_along_axis
        )
from numpy.linalg import (
        inv,
        norm,
        )

class LinearElasticNetRegression(AbstractRegression):

    def __init__(self, lambda_=1, tau=1):
        """
        Regression using square loss elastic net estimator.
        The loss function is

        1 / (2n) * ||y - Xb||^2_2 + lambda_ * ||b||_1 + (tau/2) ||b||^2_2.

        """
        super().__init__()
        self.lambda_ = lambda_
        self.tau = tau

    def fit(self, y, X, sanity_check = True, set_para = True):
        """
        solve the beta_hat using ElasticNet from sklearn.
        Set y and X.
        """

        # Get the dimensions for y and X. 
        if sanity_check:
            try:
                assert len(y) == len(X)
                assert len(y) >= 1 and len(X) >= 1
            except:
                raise Exception('The dimensions of y and X do not match. Please check.')

        elastic_net = ElasticNet(
                alpha = self.lambda_ + self.tau,
                l1_ratio = self.lambda_ / (self.lambda_ + self.tau),
                fit_intercept = False,
                max_iter = 2 * 10 ** 8,
                )

        elastic_net.fit(y=y, X=X)
        beta_hat = elastic_net.coef_

        if set_para:
            self.coef_ = beta_hat
            self.y = y
            self.X = X

        return beta_hat


    def get_crit(self):
        """
        Calculate the value of the criterion in the paper based on the current estimated beta_hat.
        Set the `self.crit`.
        """
        y = self.y
        X = self.X
        beta_hat = self.coef_
        tau = self.tau

        n = len(y)
        p = len(X[0])

        # Calcuate psi.
        residual = y - X @ beta_hat
        psi = residual

        # Calculate XS
        S_hat = nonzero(beta_hat)[0]
        XS = X[:, S_hat]

        # Calculate p_hat the number of nonzeros in beta_hat.
        p_hat = len(S_hat)

        # Calculate df and traceV.
        H = XS @ inv(XS.T @ XS + n * tau * eye(p_hat)) @ XS.T
        df = trace(H)
        trV = n - df
        df_over_trV = df / trV

        # Set self.crit.
        crit_res = norm(residual + df_over_trV * psi) ** 2
        self.crit = crit_res

    def get_ALO(self):
        """
        Calculate the ALO.
        """
        y = self.y
        X = self.X
        beta_hat = self.coef_
        tau = self.tau

        n = len(y)
        p = len(X[0])

        residual = y - X @ beta_hat

        # Calculate H
        S_hat = nonzero(beta_hat)[0]
        XS = X[:, S_hat]
        # p_hat is the number of nonzeros in beta_hat.
        p_hat = len(S_hat)
        H = XS @ inv(XS.T @ XS + n * tau * eye(p_hat)) @ XS.T

        # Calculate ALO.
        ALO = norm( residual * ( 1 / (1 - diag(H)) ) ) ** 2 / n

        self.ALO = ALO
        return ALO

    def get_ALO_and_crit(self):
        """
        Calculate ALO and crit simultaneous to save some computation.
        """
        y = self.y
        X = self.X
        beta_hat = self.coef_
        tau = self.tau

        n = len(y)
        p = len(X[0])

        # Calcuate psi.
        residual = y - X @ beta_hat
        psi = residual

        # Calculate XS
        S_hat = nonzero(beta_hat)[0]
        XS = X[:, S_hat]

        # Calculate p_hat the number of nonzeros in beta_hat.
        p_hat = len(S_hat)

        # Calculate df and traceV.
        H = XS @ inv(XS.T @ XS + n * tau * eye(p_hat)) @ XS.T
        df = trace(H)
        trV = n - df
        df_over_trV = df / trV

        # Calculate and set crit.
        crit = norm(residual + df_over_trV * psi) ** 2
        self.crit = crit

        # Calculate and set ALO.
        ALO = norm( residual * ( 1 / (1 - diag(H)) ) ) ** 2 / n
        self.ALO = ALO

        return (self.ALO, self.crit)

    @staticmethod
    def fit_get_ALO_crit_error_along_path(y, X, l1_ratio, alphas, epsilon, beta, Sigma, max_iter=2*10**8):
        """
        Use enet_path to fit linear elastic net regression along a path (a list of alphas).

        Args:
            y, X,               training data
            l1_ratio, alphas,   parameters. See loss function:

                                The parameter l1_ratio and alpha is encoding the loss function

                                1 / (2n) * ||y - Xb||^2_2
                                + alpha * l1_ratio * ||b||_1
                                + (1/2) * alpha * (1 - l1_ratio) * ||b||^2_2.

                                Can be compared to the parametrization using lambda_ and tau,

                                1 / (2n) * ||y - Xb||^2_2
                                + lambda_ * ||b||_1
                                + (1/2) * tau * ||b||^2_2.

                                So,
                                alpha * l1_ratio = lambda_,
                                alpha * (1-l1_ratio) = tau.

            epsilon, beta, Sigma,
                                background truth to calculate the errors

        Returns:
            A list of alphas
            A list of ALOs
            A list of crits over n
            A list of errors
        """
        n = len(y)
        p = len(X[0])
        alphas_list, coef_array, dual_gaps = enet_path(
                X=X,
                y=y,
                l1_ratio=l1_ratio,
                alphas=alphas,
                max_iter = max_iter,
                fit_intercept = False,
                )
        residual_array = outer(y, ones(len(alphas_list))) - X @ coef_array

        ALO_list = []
        crit_over_n_list = []

        # iterate over columns of residual_array
        for j, beta_hat in enumerate(coef_array.T):
            residual = residual_array[:, j]
            alpha = alphas_list[j]
            S_hat = nonzero(beta_hat)[0]

            # Calculate XS
            XS = X[:, S_hat]

            # Calculate p_hat the number of nonzeros in beta_hat.
            p_hat = len(S_hat)

            # Calculate df and traceV.
            H = XS @ inv(XS.T @ XS + n * alpha * (1-l1_ratio) * eye(p_hat)) @ XS.T
            df = trace(H)
            trV = n - df

            # crit
            crit = norm(residual) ** 2 * (1 + df / trV) ** 2
            crit_over_n_list.append(crit/n)

            # ALO
            ALO = norm(residual * (1 / (1 - diag(H)) ) ) ** 2 / n
            ALO_list.append(ALO)

        # error
        noise = norm(epsilon) ** 2 / len(epsilon)

        def cal_estimation_error(beta_hat):
            """
            Input a beta_hat and output its estimation error.
            The beta_hat must be a column vector.
            """
            beta_diff = beta_hat - beta
            return beta_diff @ Sigma @ beta_diff

        estimation_error = apply_along_axis(cal_estimation_error, 0, coef_array)
        error_list = noise + estimation_error
        return (alphas_list, ALO_list, crit_over_n_list, error_list)


if __name__ == "__main__":
    """
    Example: Calculate estimator
    """
    from linear_data_generator import LinearDataGenerator
    ldg = LinearDataGenerator(
            p=1000,
            n=1001,
            k=100
            )
    #ldg = LinearDataGenerator(p=100,n=101,k=10)
    elastic_net = LinearElasticNetRegression(
            lambda_ = 0.054,
            tau = 0.01,
            )
    elastic_net.fit(y=ldg.y, X=ldg.X)

    from rich import print, inspect
    inspect(elastic_net)

    """
    Example: Calculate crit and true error.
    """
    elastic_net.get_crit()
    inspect(elastic_net)
    print("Crit: ", elastic_net.crit)
    print("True noise plus estimation error: ",
        elastic_net.get_noise_plus_estimation_error(
            beta_hat = elastic_net.coef_,
            epsilon = ldg.epsilon,
            beta = ldg.beta,
            Sigma = ldg.Sigma,
        ))

    """
    Example: Calculate the leave-one-out risk estimator.
    """
    print("LO: ", elastic_net.get_leave_one_out_risk_estimate())
    """
    Example: Calculate the approximate leave-one-out risk estimator.
    """
    print("ALO: ", elastic_net.get_ALO())


    """
    Example: Fit and calculate ALO, crit, and error using enet_path along a list of alphas.
    """
    print("fit, get ALO, crit, error, .etc......")
    alphas_list, ALO_list, crit_over_n_list, error_list = LinearElasticNetRegression.fit_get_ALO_crit_error_along_path(
        y=ldg.y,
        X=ldg.X,
        l1_ratio=0.5,
        alphas=[0.018, 0.032, 0.054],
        epsilon=ldg.epsilon,
        beta=ldg.beta,
        Sigma=ldg.Sigma,
    )
    print("alphas:", alphas_list)
    print("ALO:", ALO_list)
    print("crit/n:", crit_over_n_list)
    print("error:", error_list)
