"""
Provides Fig 4 in section 5.2.1 in RM20, but with Huber ElasticNet with heavy-tailed t2 noises with ALO, criterion, and true error plotted.
"""
from linear_data_generator import LinearDataGenerator
from huber_elasticnet_regression import HuberElasticNetRegression
from math import floor
from numpy import arange, array

# Use LaTeX in matplotlib.
from latex_matplotlib import *

# Derive Fig4C class just to save some repetitive code.
from fig_4c import Fig4C

from matplotlib.pyplot import (
    plot,
    savefig,
    close,
    xscale,
    xlabel,
    ylabel,
    legend,
    title,
        )

class Fig4CHuber(Fig4C):
    """
    Provides Fig 4 in section 5.2.1 in RM20, but with Huber ElasticNet with heavy-tailed noises, and with ALO, criterion, and true error plotted.
    """
    def __init__(self):
        """
        Data used to plot figure 4c.
        """
        super().__init__()
        self.n_hat_list = []
        self.p_hat_list = []

    def cal_ALO_crit_error(self, n, p):
        """
        Generate training data and calculate ALO, crit/n, error.
        The loss function is

            (1/n) * Huber( y - Xb ; Lambda )
            + alpha * l1_ratio * ||b||_1
            + (1/2) * alpha * (1 - l1_ratio) * ||b||^2_2.

        Here, another parametrization is encoded by lambda_ and tau in HuberElasticNetRegression, where 

            alpha * l1_ratio = lambda_,
            alpha * (1-l1_ratio) = tau.

        Another parametrization is encoded by lambda_tilde and alpha_tilde in RM20.
            Huber( y - Xb ; Lambda )
            + lambda_tilde * alpha_tilde * ||b||_1
            + (1/2) * lambda_tilde * (1 - alpha_tilde) * ||b||^2_2,

        where 
            lambda_tilde = n * lambda_,
            alpha_tilde = l1_ratio.
        """

        print('Generating data...')
        ldg = LinearDataGenerator(
                n=n,
                p=p,
                k=floor(n/10),
                # The setting is similar to that in fig 4c in RM20.
                # We generate heavy-tailed noises instead of normal noises.
                beta='laplace',
                epsilon='t2', 
                Sigma='spiked',
                X=True,
                )
        print('Data generated.')

        #print('Inspect data...')
        #from rich import inspect
        #inspect(ldg)
        #print('Data inspected.')

        l1_ratio = 0.5
        lambda_tilde_list = 10 ** arange(0, 2.01, 2/29)
        alpha_list = lambda_tilde_list / n

        print('Fit coef and calculate ALO, crit, error...Might take minutes due to the max_n_iter=2*10**8 for Gradient Descent to converge...')

        ALO_list = []
        crit_over_n_list = []
        error_list = []
        n_hat_list = []
        p_hat_list = []

        for alpha in alpha_list:
            huber_elasticnet = HuberElasticNetRegression(
                    Lambda = 0.054 * n ** (1/2),
                    lambda_ = alpha * l1_ratio,
                    tau = alpha * (1-l1_ratio),
                    )
            huber_elasticnet.fit(y=ldg.y, X=ldg.X)
            ALO, crit = huber_elasticnet.get_ALO_and_crit()
            error = huber_elasticnet.get_noise_plus_estimation_error(
                    beta_hat = huber_elasticnet.coef_,
                    epsilon = ldg.epsilon,
                    beta = ldg.beta,
                    Sigma = ldg.Sigma,
                    )

            ALO_list.append(ALO)
            crit_over_n_list.append(crit / n)
            error_list.append(error)
            n_hat_list.append(huber_elasticnet.n_hat)
            p_hat_list.append(huber_elasticnet.p_hat)

        self.lambda_tilde_list = alpha_list * n
        self.ALO_list = ALO_list
        self.crit_over_n_list = crit_over_n_list
        self.true_error_list = error_list
        self.n_hat_list = n_hat_list
        self.p_hat_list = p_hat_list

    def run(self, n, p, filename):
        """
        Generate data and plot figure 4c but with Huber loss.
        """
        self.cal_ALO_crit_error(n,p)
        self.plot(filename=filename + '.pdf', titlename=f'n={n},p={p}')
        self.plot_outlier(
                outlier_list = n - array(self.n_hat_list),
                filename=filename + '_outlier.pdf', 
                titlename = f'n={n},p={p}'
                )

    def plot_outlier(self, outlier_list, filename, titlename):
        """
        Plot the number of outliers associated with the fig 4c plots.  
        """

        # Plot ALO, crit/n, true error.
        plot(
            self.lambda_tilde_list,
            outlier_list,
            '-+',
            label='outlier',
            )

        # Additional plotting options.
        legend()
        xscale('log')
        xlabel(r'$\lambda$')
        ylabel('number of outliers')
        title(titlename)
        savefig(
            fname=filename,
            dpi=300,
            )
        print(f"The figure {filename} has been exported.")
        close()


if __name__ == '__main__':
    fig_4c_huber = Fig4CHuber()
    path = 'fig4c_huber_with_outliers/'
    fig_4c_huber.run(n=1000, p=200, filename=path+'fig4a')
    fig_4c_huber.run(n=1000, p=1000, filename=path+'fig4b')
    fig_4c_huber.run(n=1000, p=10000, filename=path+'fig4c')
    for i in range(10):
        fig_4c_huber.run(n=500, p=5000, filename=path+f'fig4c_500_{i}')
    for i in range(10):
        fig_4c_huber.run(n=1000, p=10000, filename=path+f'fig4c_1000_{i}')
