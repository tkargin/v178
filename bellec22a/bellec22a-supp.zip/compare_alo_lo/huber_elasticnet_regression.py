"""
Provides the Huber Elastic-Net estimator based on LassoLars.
"""
from sklearn.linear_model import (
        LassoLars,
        )

from abstract_regression import AbstractRegression
from numpy import (
        trace,
        hstack,
        concatenate,
        vstack,
        eye,
        zeros,
        sqrt,
        clip,
        nonzero,
        where,
        diag,
        allclose,
        count_nonzero,
        )
from numpy.linalg import (
        norm,
        inv,
        )
from warnings import warn

class HuberElasticNetRegression(AbstractRegression):
    """
    Regression using Huber loss and Elastic Net penalty.
    Implemented using LassoLars in sklearn.

    The estimator minimizes the following loss function
    over a p-by-1 vector b,

    L(b) = (1/n) sum_i rho( y_i - x_i ^T b) + g(b),
    where rho(u) = Lambda^2 H (Lambda^{-1} u).

    H is the standard Huber's loss, and
    g(b) = lambda * ||b||_1 + (tau / 2) ||b||_2^2.
    """
    def __init__(self, Lambda=1, lambda_=1, tau=1):
        """
        Args:
            Lambda: tuning parameter. positive real.
            lambda_: tuning parameter. positive real.
            tau: tuning parameter. positive real.
        """
        super().__init__()
        self.Lambda = Lambda
        self.lambda_ = lambda_
        self.tau = tau
        self.n_hat = None
        self.p_hat = None

    def fit(self, y, X, sanity_check = True, set_para = True):
        """
        Solve the Huber Elastic Net regression by using LassoLars from sklearn,
        and assign the estimator to the `self.coef_`.

        The algorithm of solving beta_hat is by calculating

        beta_hat, theta_hat = argmin_{b,theta}

        (1/(2n)) || [Lambda^{-1}y^T 0^T]^T - [ Lambda^{-1}X nLambda^{-2}lambdaI, (n tau)^{1/2}Lambda^{-1}0] [b^T theta^T]^T ||_2^2
        + Lambda^{-2} lambda || [b^T, theta^T]^T ||_1.

        Args:
            y: 1-D array. observations. n by 1.
            X: 2-D array. observed features. n by p.
            sanity_check: bool. whether to perform sanity check. False for fast experiments.
            set_para: bool. Whether to set the parameters.

        Returns:
            None
        """

        # Get the dimensions for y and X. 
        if sanity_check:
            try:
                assert len(y) == len(X)
                assert len(y) >= 1 and len(X) >= 1
            except:
                raise Exception('The dimensions of y and X do not match. Please check.')

        n = len(y)
        p = len(X[0])

        Lambda = self.Lambda
        lambda_ = self.lambda_
        tau = self.tau

        lasso_lars = LassoLars(
                alpha = (n / (n + p)) * Lambda ** (-2) * lambda_,
                fit_intercept = False,
                max_iter=2 * 10 ** 8,
                )

        lasso_lars.fit(
                y=concatenate([Lambda ** (-1) * y, zeros(p)]),
                X=vstack([
                        hstack([Lambda ** (-1) * X, n * Lambda ** (-2) * lambda_ * eye(n)]),
                        hstack([sqrt(n * tau) * Lambda ** (-1) * eye(p), zeros((p, n))]),
                    ]),
                )

        # estimates
        beta_hat = lasso_lars.coef_[:p]

        if set_para:
            self.coef_ = beta_hat

            # store training data 
            self.y = y
            self.X = X

        if sanity_check:
            theta_hat = lasso_lars.coef_[p:p+n]

            # ##### 
            # 
            # related quantities
            # 
            # residual: estimation residual. 
            # psi: clipped residual.
            # S_hat: number of non-zero elements in beta_hat.
            # num_outliers: number of outliers.
            # num_inliers: number of inliers, number of clipped residuals.
            # 
            # #####

            residual = y - X @ beta_hat
            psi = clip(residual, -Lambda, Lambda)
            is_inlier = (abs(residual) <= Lambda)
            S_hat = nonzero(beta_hat)[0]
            outlier_index = nonzero(theta_hat)[0]
            inlier_index = where(is_inlier)[0]
            #D = diag(is_inlier)

            # ##### 
            # 
            # sanity-check
            # 
            # The sanity_vec_1 shall be a zero vector. 
            # Some tests may fail due to numerical instability
            # floating point issues.
            # In that case the norm (printed) should be small.
            #
            # #####

            zeros_n = zeros(n)
            sanity_vec_1 = psi - (y - X @ beta_hat - n * Lambda ** (-1) * lambda_ * theta_hat)
            try:
                assert allclose(sanity_vec_1, zeros_n)
            except AssertionError:
                warn(f'Sanity check warning: the norm of psi - (y - X @ beta_hat - n * lambda_ * theta_hat) is large: {norm(sanity_vec_1)}')

            del zeros_n

            # Another sanity check. 
            # May fail if some residuals fall (up to
            # floating point precision) where psi'( ) is discontinuous.

            # May also fail due to the numerical instability when solving the Lasso problem.

            try:
                assert len(outlier_index) + len(inlier_index) == n
            except AssertionError:
                warn(
                    f'Sanity check warning: number of non-zero elements in theta: {len(outlier_index)}, number of inliners: {len(inlier_index)}'
                )

            if set_para:
                self.n_hat = len(inlier_index)
                self.p_hat = len(S_hat)

        return beta_hat

    def get_ALO(self):
        """
        Calculate the ALO in RM20 based on the current estimated beta_hat.
        """
        y = self.y
        X = self.X
        beta_hat = self.coef_
        Lambda = self.Lambda
        tau = self.tau

        n = len(y)
        p = len(X[0])

        # Calcuate psi.
        residual = y - X @ beta_hat
        psi = clip(residual, -Lambda, Lambda)

        # Calculate DXS
        S_hat = nonzero(beta_hat)[0]
        is_inlier = (abs(residual) <= Lambda)
        D = diag(is_inlier)
        XS = X[:, S_hat]
        DXS = D @ XS

        # Calculate A
        A_SS = inv(DXS.T @ DXS + n * tau * eye(len(S_hat)))
        XAX = XS @ A_SS @ XS.T
        diagG = diag(XAX) * psi
        diagH = diag(XAX) * is_inlier
        ALO = norm(residual + diagG / (1 - diagH)) ** 2 / n

        self.ALO = ALO
        return ALO

    def get_ALO_and_crit(self):
        """
        Calculate the ALO and the crit simultaneously to reduce computation.

        Returns:
            ALO, 
            crit,
        """
        y = self.y
        X = self.X
        beta_hat = self.coef_
        Lambda = self.Lambda
        tau = self.tau

        n = len(y)
        p = len(X[0])

        # Calcuate psi.
        residual = y - X @ beta_hat
        psi = clip(residual, -Lambda, Lambda)

        # Calculate DXS
        S_hat = nonzero(beta_hat)[0]
        is_inlier = (abs(residual) <= Lambda)
        D = diag(is_inlier)
        XS = X[:, S_hat]
        DXS = D @ XS

        # Calculate ALO
        A_SS = inv(DXS.T @ DXS + n * tau * eye(len(S_hat)))
        XAX = XS @ A_SS @ XS.T
        diagG = diag(XAX) * psi
        diagH = diag(XAX) * is_inlier
        ALO = norm(residual + diagG / (1 - diagH)) ** 2 / n 
        self.ALO = ALO

        # Calculate n_hat, the number of inliers, and p_hat the number of nonzeros in beta_hat.
        n_hat = count_nonzero(is_inlier)
        p_hat = len(S_hat)

        # Calculate df and traceV.
        df = sum(diagH) if n_hat > 0 else 0
        trV = n_hat - df
        df_over_trV = df / trV

        # Calculate crit.
        crit = norm(residual + df_over_trV * psi) ** 2
        self.crit = crit

        return (self.ALO, self.crit)


    def get_ALO_crit_and_unob_crit(self, Sigma):
        """
        Calculate the ALO, the crit, and the unobservable crit 
        simultaneously to reduce computation.

        Args:
            Sigma: The matrix used to calculate trace[Sigma A]

        Returns:
            ALO, 
            crit,
            unob_crit,
        """
        y = self.y
        X = self.X
        beta_hat = self.coef_
        Lambda = self.Lambda
        tau = self.tau

        n = len(y)
        p = len(X[0])

        # Calcuate psi.
        residual = y - X @ beta_hat
        psi = clip(residual, -Lambda, Lambda)

        # Calculate DXS
        S_hat = nonzero(beta_hat)[0]
        is_inlier = (abs(residual) <= Lambda)
        D = diag(is_inlier)
        XS = X[:, S_hat]
        DXS = D @ XS

        # Calculate ALO
        A_SS = inv(DXS.T @ DXS + n * tau * eye(len(S_hat)))
        XAX = XS @ A_SS @ XS.T
        diagG = diag(XAX) * psi
        diagH = diag(XAX) * is_inlier
        ALO = norm(residual + diagG / (1 - diagH)) ** 2 / n 
        self.ALO = ALO

        # Calculate n_hat, the number of inliers, and p_hat the number of nonzeros in beta_hat.
        n_hat = count_nonzero(is_inlier)
        p_hat = len(S_hat)

        # Calculate df and traceV.
        df = sum(diagH) if n_hat > 0 else 0
        trV = n_hat - df
        df_over_trV = df / trV

        # Calculate trace_Sigma_A
        SigmaSS = Sigma[:, S_hat][S_hat, :]
        trace_Sigma_A = trace(
            SigmaSS @ A_SS
        ) if n_hat > 0 else 0

        # Calculate crit.
        crit = norm(residual + df_over_trV * psi) ** 2
        self.crit = crit

        # Calculate unobservable crit.
        unob_crit = norm(residual + trace_Sigma_A * psi) ** 2

        return (self.ALO, self.crit, unob_crit)

    def get_ALO_crit_unob_crit_and_many_others(self, Sigma):
        """
        Calculate the ALO, the crit, the unobservable crit, and many other quantities
        simultaneously to reduce computation, including
            df/n
            p_hat/n
            n_hat/n
            |df-trSigmaAtrV|/n
            trSigmaA
            |trSigmaA-df/trV|
            ALO
            crit
            unob_crit

        Args:
            Sigma: The matrix used to calculate trace[Sigma A]

        Returns:
            result: A dict containing many quantities
        """
        y = self.y
        X = self.X
        beta_hat = self.coef_
        Lambda = self.Lambda
        tau = self.tau

        result = {} # result dictionary

        n = len(y)
        p = len(X[0])

        # Calcuate psi.
        residual = y - X @ beta_hat
        psi = clip(residual, -Lambda, Lambda)

        # Calculate DXS
        S_hat = nonzero(beta_hat)[0]
        is_inlier = (abs(residual) <= Lambda)
        D = diag(is_inlier)
        XS = X[:, S_hat]
        DXS = D @ XS

        # Calculate ALO
        A_SS = inv(DXS.T @ DXS + n * tau * eye(len(S_hat)))
        XAX = XS @ A_SS @ XS.T
        diagG = diag(XAX) * psi
        diagH = diag(XAX) * is_inlier
        ALO = norm(residual + diagG / (1 - diagH)) ** 2 / n 
        self.ALO = ALO

        # Calculate n_hat, the number of inliers, and p_hat the number of nonzeros in beta_hat.
        n_hat = count_nonzero(is_inlier)
        p_hat = len(S_hat)

        # register results
        result['n_hat/n'] = n_hat/n
        result['p_hat/n'] = p_hat/n

        # Calculate df and traceV.
        df = sum(diagH) if n_hat > 0 else 0
        trV = n_hat - df
        df_over_trV = df / trV

        # register results
        result['df/n'] = df/n

        # Calculate trace_Sigma_A
        SigmaSS = Sigma[:, S_hat][S_hat, :]
        trace_Sigma_A = trace(
            SigmaSS @ A_SS
        ) if n_hat > 0 else 0

        # register results
        result['trSigmaA'] = trace_Sigma_A
        result['|df-trSigmaAtrV|/n'] = abs(df - trace_Sigma_A * trV) / n
        result['|trSigmaA-df/trV|'] = abs(trace_Sigma_A - df_over_trV)
            

        # Calculate crit.
        crit = norm(residual + df_over_trV * psi) ** 2
        self.crit = crit

        # Calculate unobservable crit.
        unob_crit = norm(residual + trace_Sigma_A * psi) ** 2

        # result register
        result['ALO'] = ALO
        result['crit'] = crit
        result['unob_crit'] = unob_crit

        return result

    def get_crit(self):
        """
        Calculate the value of the criterion in the paper based on the current estimated beta_hat.
        Set the `self.crit`.
        """
        y = self.y
        X = self.X
        beta_hat = self.coef_
        Lambda = self.Lambda
        tau = self.tau

        n = len(y)
        p = len(X[0])

        # Calcuate psi.
        residual = y - X @ beta_hat
        psi = clip(residual, -Lambda, Lambda)

        # Calculate DXS
        S_hat = nonzero(beta_hat)[0]
        is_inlier = (abs(residual) <= Lambda)
        D = diag(is_inlier)
        DXS = D @ X[:, S_hat]

        # Calculate n_hat, the number of inliers, and p_hat the number of nonzeros in beta_hat.
        n_hat = count_nonzero(is_inlier)
        p_hat = len(S_hat)

        # Calculate df and traceV.
        df = trace(
            DXS @ inv(DXS.T @ DXS + n * tau * eye(p_hat)) @ DXS.T
        ) if n_hat > 0 else 0
        trV = n_hat - df
        df_over_trV = df / trV

        # Set self.crit.
        crit = norm(residual + df_over_trV * psi) ** 2
        self.crit = crit
        return crit


if __name__ == '__main__':
    """
    Example: Calculate estimator.
    """
    from linear_data_generator import LinearDataGenerator
    n, p, k = 1001, 1000, 100
    ldg = LinearDataGenerator(n=n,p=p,k=k)
    huber_elasticnet = HuberElasticNetRegression(
            Lambda = 0.054 * n ** (1/2),
            #lambda_ = 0.054,
            #tau = 0.01,
            lambda_ = 0.0032,
            tau = 0.1,
            )
    huber_elasticnet.fit(y=ldg.y, X=ldg.X)

    from rich import print, inspect
    inspect(huber_elasticnet)

    """
    Example: Calculate the criterion.
    """
    crit = huber_elasticnet.get_crit()
    print('crit/n: ', crit/n)

    """
    Example: Calculate the true noise plus estimation error.
    """
    true_error = huber_elasticnet.get_noise_plus_estimation_error(
            beta_hat = huber_elasticnet.coef_,
            epsilon = ldg.epsilon,
            beta = ldg.beta,
            Sigma = ldg.Sigma,
            )
    print('true_error: ', true_error)
    """
    Example: Calculate the leave-one-out risk estimator.
    """
    #print('LO: ', huber_elasticnet.get_leave_one_out_risk_estimate())

    """
    Example: Calculate the approximate leave-one-out risk estimator.
    """
    ALO = huber_elasticnet.get_ALO()
    print('ALO: ', ALO)

    """
    Example: Compare the ALO - noise, the crit - ALO, and the estimation error.
    """
    noise = norm(ldg.epsilon) ** 2 / n
    print('ALO - noise: ', ALO - noise)
    print('crit/n - noise: ', crit/n - noise)
    print('estimation error: ', true_error - noise)
