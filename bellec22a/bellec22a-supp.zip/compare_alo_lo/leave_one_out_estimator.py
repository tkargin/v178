"""
Provides leave-one-out estimator of the out-of-sample error for an estimator of beta.
"""
from sklearn.model_selection import LeaveOneOut
from numpy import mean
from rich.progress import Progress

class LeaveOneOutRiskEstimator:
    """
    Provides leave-one-out out-of-sample risk estimator.
    """

    def __init__(self, y, X, beta_estimator, loss_function = lambda a,b: (a-b)**2):
        """
        Args:
            beta_estimator: a function that maps y and X to the beta_hat.
            loss_function: a function that measurs the closeness between y and x^T @ beta, and will be used to define the out-of-sample error. For e.g., square loss. 
        """
        self.y = y
        self.X = X
        self.beta_estimator = beta_estimator
        self.leave_one_out_estimate = None
        self.loss_function = loss_function

    def get_leave_one_out_estimate(self, sanity_check = True):
        """
        Calculate the leave-one-out estimate of the out-of-sample error.
        Very costly.
        """
        X = self.X
        y = self.y
        loo = LeaveOneOut()
        num_splits = loo.get_n_splits(X)

        if sanity_check:
            try:
                assert num_splits == len(X)
            except:
                raise Exception("The number of splits does not equal to the number of rows.")

        error_list = []

        with Progress() as progress:
            task = progress.add_task("Calculating leave-one-out risk estimator...", total = num_splits)
            for train_index, test_index in loo.split(X):
                X_train, X_test = X[train_index], X[test_index]
                y_train, y_test = y[train_index], y[test_index]
                beta_hat = self.beta_estimator(y=y_train, X=X_train)
                error = self.loss_function(y_test, X_test @ beta_hat)
                error_list.append(error)
                progress.update(task, advance = 1)

        mean_error = mean(error_list)
        self.leave_one_out_estimate = mean_error
        return mean_error


if __name__ == "__main__":
    """
    Example 1. Huber Elastic Net leave-one-out risk estimate. 
    """

    # generate data. 
    from linear_data_generator import LinearDataGenerator
    ldg = LinearDataGenerator(p=100,n=101,k=10)

    # construct beta_estimator.
    from huber_elasticnet_estimator import HuberElasticNetRegression
    def huber_elasticnet_beta_hat(y, X):
        """
        Return beta_hat from y and X using huber elasticnet.
        """
        huber_elasticnet = HuberElasticNetRegression(
            Lambda = 0.054 * 1001 ** (1/2),
            lambda_ = 0.054,
            tau = 0.01,
            )
        huber_elasticnet.fit(y=y, X=X)
        beta_hat = huber_elasticnet.coef_
        return beta_hat

    loore = LeaveOneOutRiskEstimator(
            y = ldg.y,
            X = ldg.X, 
            beta_estimator = huber_elasticnet_beta_hat,
            loss_function = lambda a,b: (a-b) ** 2,
            )
    loore.get_leave_one_out_estimate()

    from rich import inspect
    inspect(loore)
