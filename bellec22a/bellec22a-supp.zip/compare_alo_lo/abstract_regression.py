from abc import ABC, abstractmethod
from numpy.linalg import norm
from leave_one_out_estimator import LeaveOneOutRiskEstimator

class AbstractRegression(ABC):
    """
    An abstract class for regressions.
    """

    @abstractmethod
    def __init__(self):
        """
        Args:
            y:
            X:
            coef_: beta_hat
            crit: the value of the criterion
            LO: leave-one-out estimate
            ALO: Approximate leave-one-out estimate
        """
        self.y = None
        self.X = None
        self.coef_ = None
        self.crit = None
        self.LO = None
        self.ALO = None

    @abstractmethod
    def fit(self, y, X, sanity_check = True, set_para = True):
        """
        Args:
            y: 1-D array. observations. n by 1.
            X: 2-D array. observed features. n by p.
            sanity_check: bool. whether to perform sanity check. False for fast experiments.
            set_para: bool. Whether to set the parameters.
        """
        pass

    @staticmethod
    def get_noise_plus_estimation_error(beta_hat, epsilon, beta, Sigma):
        """
        Calculate the value of error || epsilon ||^2 / n + || beta_hat - beta ||^2 based on the current beta_hat.

        Args:
            epsilon: the true noise vector.
            beta: the true beta.
            Sigma: the covariance matrix of rows of X.

        return:
            Noise + Estimation Error.
        """
        noise = norm(epsilon) ** 2 / len(epsilon)
        beta_diff = beta_hat - beta
        estimation_error = beta_diff @ Sigma @ beta_diff
        return noise + estimation_error

    def get_leave_one_out_risk_estimate(self):
        """
        Calculate the leave-one-out estimate of the out-of-sample error based on the current self.y and self.X.
        """
        def get_beta(y, X):
            return self.fit(y=y, X=X, sanity_check=True, set_para=False)

        loore = LeaveOneOutRiskEstimator(
                y = self.y,
                X = self.X,
                beta_estimator = get_beta,
                loss_function = lambda a,b: (a-b) ** 2,
                )
        loore_value = loore.get_leave_one_out_estimate()
        self.LO = loore_value
        return loore_value

    @abstractmethod
    def get_ALO(self):
        """
        Calculate the approximate leave-one-out estimate of the out-of-sample error based on the current self.y and self.X.
        See RM20.
        """
        pass


if __name__ == "__main__":
    pass

