"""
Provides Fig 4 in section 5.2.1 in RM20, but with ALO, criterion, and true error plotted.
"""
from linear_data_generator import LinearDataGenerator
from linear_elasticnet_regression import LinearElasticNetRegression
from rich import inspect
from math import floor
from numpy import (
        arange,
        )
from matplotlib.pyplot import (
    plot,
    savefig,
    close,
    xscale,
    xlabel,
    ylabel,
    legend,
    title,
        )
# Use LaTeX in matplotlib.
from latex_matplotlib import *

class Fig4C:
    """
    Provide fig 4c in RM20.
    """
    def __init__(self):
        """
        Data used to plot figure 4c.
        Args:
            lambda_tilde, 
                lambda_tilde is the lambda in figure 4c in RM20.
        """
        self.lambda_tilde_list = None
        self.ALO_list = None
        self.crit_over_n_list = None
        self.true_error_list = None

    def inspect_attributes(self):
        """
        Inspect the data attributes in the Fig4C.
        """
        inspect(self)

    def plot(self, filename, titlename):
        """
        Plot the scatter plots based on the data attributes.
        """
        # Plot ALO, crit/n, true error.
        plot(
            self.lambda_tilde_list,
            self.ALO_list,
            '-+',
            label='ALO',
            )
        plot(
            self.lambda_tilde_list,
            self.crit_over_n_list,
            '-+',
            label='crit/n',
            )
        plot(
            self.lambda_tilde_list,
            self.true_error_list,
            '-+',
            label='noise + estimation error',
            )
        # Additional plotting options.
        legend()
        xscale('log')
        xlabel(r'$\lambda$')
        ylabel('Mean Square Error')
        title(titlename)
        savefig(
            fname=filename,
            dpi=300,)
        print(f"The figure {filename} has been exported.")
        close()

    def cal_ALO_crit_error(self, n, p):
        """
        Generate training data and calculate ALO, crit/n, error.
        The loss function is,

            1 / (2n) * ||y - Xb||^2_2
            + alpha * l1_ratio * ||b||_1
            + (1/2) * alpha * (1 - l1_ratio) * ||b||^2_2.

        which is equivalent to 

            (1 / 2) * ||y - Xb||^2_2
            + lambda_tilde * alpha_tilde * ||b||_1
            + (1/2) * lambda_tilde * (1 - alpha_tilde) * ||b||^2_2,

        where 
            lambda_tilde = alpha * n,
            alpha_tilde = l1_ratio.

        """
        k = floor(n / 10)
        l1_ratio = 0.5
        lambda_tilde_list = 10 ** arange(0, 2.01, 2/29)
        alphas = lambda_tilde_list / n

        print('Generating data...')
        ldg = LinearDataGenerator(
                n=n,
                p=p,
                k=k,
                beta='laplace',
                epsilon='normal1',
                Sigma='spiked',
                X=True,
                )
        print('Data generated.')

        #print('Inspect data...')
        #inspect(ldg)
        #print('Data inspected.')

        print('Fit coef and calculate ALO, crit, error...Might take minutes due to the max_n_iter=2*10**8 for Gradient Descent to converge...')
        alphas_list, ALO_list, crit_over_n_list, error_list = LinearElasticNetRegression.fit_get_ALO_crit_error_along_path(
            y=ldg.y,
            X=ldg.X,
            l1_ratio=l1_ratio,
            alphas=alphas,
            epsilon=ldg.epsilon,
            beta=ldg.beta,
            Sigma=ldg.Sigma,
            max_iter=2*10**8,
        )

        self.lambda_tilde_list = alphas_list * n
        self.ALO_list = ALO_list
        self.crit_over_n_list = crit_over_n_list
        self.true_error_list = error_list

    def run(self, n, p, filename):
        """
        Plot figure 4c in RM20 with crit/n added.
        """
        self.cal_ALO_crit_error(n, p)
        #self.inspect_attributes()
        self.plot(filename=filename, titlename=f'n={n},p={p}')


if __name__ == '__main__':
    fig_4c = Fig4C()
    fig_4c.run(n=1000, p=200, filename='fig4c/fig4a.pdf')
    fig_4c.run(n=1000, p=1000, filename='fig4c/fig4b.pdf')
    fig_4c.run(n=1000, p=10000, filename='fig4c/fig4c.pdf')
    for i in range(10):
        fig_4c.run(n=500, p=5000, filename=f'fig4c/fig4c_500_{i}.pdf')
    for i in range(10):
        fig_4c.run(n=1000, p=10000, filename=f'fig4c/fig4c_1000_{i}.pdf')
