"""
Provides heatmap figures.
    Folder: fig2
    Estimator: Linear Elastic Net
    Noise: normal1
    Quantities: ALO, crit, true_error
"""
PATH = 'fig2/'

from heatmap_plotter import (
    HeatmapData,
    HeatmapPlotter,
    )
from numpy import (
    array, 
    mean,
    )
from numpy.linalg import (
    norm,
    )
from linear_data_generator import LinearDataGenerator 
from linear_elasticnet_regression import (
        LinearElasticNetRegression,
        )
from rich.progress import Progress
from rich import inspect

class HeatmapSetup2:
    """
    Provide a heatmap setup.
    """
    def __init__(self):
        pass

    def run(self):
        """
        Example: Linear ElasticNet Regression
        """
        n,p,k = 1001,1000,100
        heatmap_data = HeatmapData(
            index_name = r'$\tau$',
            index = [
                10 ** (-10), 
                10 ** (-7), 
                10 ** (-5), 
                10 ** (-3), 
                10 ** (-2), 
                10 ** (-1.5), 
                10 ** (-1.2), 
                10 ** (-1),
                ],
            columns_name = r'$\lambda$',
            columns = n ** (-1/2) * array(
                [0.1 * 1.5 ** k for k in range(13)]
                ),
            quantity_name_list = [
                'ALO_minus_noise',
                'crit_over_n_minus_noise',
                'estimation_error',
                ])

        with Progress() as progress:
            task = progress.add_task(
                    "Generating heatmap data (in total)...",
                    total = len(heatmap_data.index) * len(heatmap_data.columns),
                    )
            sample_size_per_grid = 2
            task_current_grid = progress.add_task(
                    "Generating heatmap data (for the current grid)...",
                    total = sample_size_per_grid,
                    )

            for tau in heatmap_data.index:
                for lambda_ in heatmap_data.columns:
                    ALO_minus_noise_array = []
                    crit_over_n_minus_noise_array = []
                    estimation_error_array = []

                    for i in range(sample_size_per_grid):
                        # Generate Data.
                        ldg = LinearDataGenerator(
                                p=p, n=n, k=k,
                                epsilon='normal1',
                            )
                        elastic_net = LinearElasticNetRegression(
                                lambda_ = lambda_,
                                tau = tau,
                                )
                        elastic_net.fit(y=ldg.y, X=ldg.X)

                        # Calculate ALO, crit and True.
                        ALO, crit = elastic_net.get_ALO_and_crit()

                        noise_plus_estimation_error = elastic_net.get_noise_plus_estimation_error(
                            beta_hat = elastic_net.coef_,
                            epsilon = ldg.epsilon,
                            beta = ldg.beta,
                            Sigma = ldg.Sigma,
                        )
                        noise = norm(ldg.epsilon) ** 2 / n
                        estimation_error = noise_plus_estimation_error - noise
                        ALO_minus_noise_array.append(ALO - noise)
                        crit_over_n_minus_noise_array.append(crit/n - noise)
                        estimation_error_array.append(estimation_error)
                        progress.update(task_current_grid, advance = 1)

                    progress.update(
                            task_current_grid,
                            advance = -sample_size_per_grid,
                            )
                    dataframe_dict = heatmap_data.heatmap_dataframe_dict
                    dataframe_dict['ALO_minus_noise'].loc[tau, lambda_] = mean(ALO_minus_noise_array)
                    dataframe_dict['crit_over_n_minus_noise'].loc[tau, lambda_] = mean(crit_over_n_minus_noise_array)
                    dataframe_dict['estimation_error'].loc[tau, lambda_] = mean(estimation_error_array)
                    progress.update(task, advance = 1)

        inspect(heatmap_data)
        heatmap_plotter = HeatmapPlotter(
                heatmap_data = heatmap_data
                )
        inspect(heatmap_plotter)
        heatmap_plotter.plot(
                titlenames = [
                    r'$\text{ALO}-\|\bep\|^2/n$',
                    # criterion minus noise
                    r'$\|\br+\frac{\df}{\trace[\bV]}\bpsi\|^2/n-\|\bep\|^2/n$',
                    # estimation error
                    r'$\|\bSigma^{1/2}(\hbbeta-\bbeta^*)\|^2/n$',
                    ],
                filenames = [PATH + string for string in 
                    [
                    'ALO_minus_noise.pdf',
                    'crit_over_n_minus_noise.pdf',
                    'estimation_error.pdf',
                    ]],
                vmin=0,
                vmax=12,
                )
        heatmap_data.dump(filename=PATH+'data.b')

if __name__ == '__main__':
    heatmap_setup2 = HeatmapSetup2()
    heatmap_setup2.run()
