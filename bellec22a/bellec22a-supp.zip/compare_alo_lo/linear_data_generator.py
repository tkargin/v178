"""
Provides the linear data generator which generates the training data.
"""
from math import sqrt
from numpy import (
        concatenate,
        ones,
        zeros,
        eye,
        real,
        )
from numpy.random import (
        randn,
        multivariate_normal,
        standard_cauchy,
        standard_t,
        uniform,
        poisson,
        binomial,
        laplace
        )

class LinearDataGenerator:
    """
    Generate data from a linear model.
    Returns y, X from hyper-parameters.

    Args:
        p: number of features
        n: number of observations
        k: number of non-zero elements in beta (used to generate true beta)
        beta: the true coefficients
        epsilon: the noise vector
        X: the feature matrix
        y: the observation vector
        Sigma: the covariance matrix of the rows of X

    """
    def __init__(self,
            n=1001,
            p=1000,
            k=100,
            beta=True,
            epsilon=True,
            Sigma=True,
            X=True,
            ):
        """
        """
        self.n = n
        self.p = p
        self.k = k
        self.beta = None
        self.epsilon = None
        self.X = None
        self.y = None
        self.Sigma = None
        self._set(
                beta=beta,
                epsilon=epsilon,
                Sigma=Sigma,
                X=X,
                )

    def _set(
            self,
            beta=True,
            epsilon=True,
            Sigma=True,
            X=True,
            ):
        """
        Set hyper parameters.
        Args:

            beta:
                If False, not set.
                If True, generate default 'ones'.
                If string, generate according to type.
                    The string can be 'laplace', 'ones'.
                If given, set to fixed.

            epsilon:
                If False, not set.
                If True, generate default 't2'.
                If string, generate according to type.
                    The string can be 'normal1', 'normal2', 'cauchy', 't2', 'uniform1', 'uniform10', 'poisson'.
                If given, set to fixed.

            Sigma:
                The covariance matrix of X.
                If False, not set.
                If True, generate default 'rademacher'.
                If string, generate according to type.
                    The string can be 'rademacher', 'identity'.
                If given, set to fixed.

            X:
                If False, not set.
                If True, generate default.
                If given, set to fixed.
        """

        # Set beta.
        if beta == False:
            pass
        elif beta == True:
            self.beta = concatenate([ones(self.k), zeros(self.p-self.k)]) * (self.p ** (1/2) / self.k)
        elif beta == 'laplace':
            self.beta = concatenate([laplace(scale = sqrt(2)/2, size=self.k), zeros(self.p-self.k)])
        elif beta == 'ones':
            self.beta = concatenate([ones(self.k), zeros(self.p-self.k)]) * (self.p ** (1/2) / self.k)
        else:
            self.beta = beta

        # Set epsilon.
        if epsilon == False:
            pass
        elif epsilon == True:
            self.epsilon = standard_t(df=2,size=self.n)
        elif epsilon == 'normal1':
            self.epsilon = randn(self.n)
        elif epsilon == 'normal2':
            self.epsilon = 2 * randn(self.n)
        elif epsilon == 'cauchy':
            self.epsilon = standard_cauchy(self.n)
        elif epsilon == 't2':
            self.epsilon = standard_t(df=2,size=self.n)
        elif epsilon == 'uniform1':
            self.epsilon = uniform(-1,1,size=self.n)
        elif epsilon == 'uniform10':
            self.epsilon = uniform(-10,10,size=self.n)
        elif epsilon == 'poisson':
            self.epsilon = poisson(lam=1,size=self.n)
        else:
            self.epsilon = epsilon

        # Set Sigma.
        if Sigma == False:
            pass
        elif Sigma == True:
            rademacher_matrix = (-1) ** binomial(1, 0.5, size=(2*self.p, self.p))
            self.Sigma = rademacher_matrix.T @ rademacher_matrix / (2*self.p)
        elif Sigma == 'identity':
            self.Sigma = eye(self.p)
        elif Sigma == 'rademacher':
            rademacher_matrix = (-1) ** binomial(1, 0.5, size=(2*self.p, self.p))
            self.Sigma = rademacher_matrix.T @ rademacher_matrix / (2*self.p)
        elif Sigma == 'spiked':
            Sigma_tilde = 0.5 * (eye(self.p) + ones((self.p, self.p)))
            denominator = self.beta @ Sigma_tilde @ self.beta
            self.Sigma = Sigma_tilde / denominator
        else:
            self.Sigma = Sigma

        # Set X.
        if X == False:
            pass
        elif X == True:
            # Using multivariate_normal avoids using sqrtm.
            self.X = multivariate_normal(
                    mean=zeros(self.p),
                    cov=self.Sigma,
                    size=self.n,
                    )
        else:
            self.X = X

        # Set y.
        self.y = self.X @ self.beta + self.epsilon

if __name__ == '__main__':
    """
    Example
    """
    from rich import inspect
    ldg = LinearDataGenerator(
            n=1001,
            p=1000,
            k=100,
            beta='laplace',
            epsilon='normal1',
            Sigma='spiked',
            X=True,
            )
    inspect(ldg)
    vector = ldg.X @ ldg.beta
    from numpy import mean, var
    print('mean, var: ', mean(vector), var(vector))
