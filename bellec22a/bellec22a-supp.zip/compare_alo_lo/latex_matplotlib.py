"""
Provides settings for matplotlib plotting with Latex.
"""

##### 
#
# Use LaTeX in matplotlib plotting
# with preamble
#
#####
from matplotlib.pyplot import rcParams
LaTeX_setup = {
    'text.usetex': True,
    'font.family': 'sans-serif',
    'font.sans-serif': ['cm10'],
    'text.latex.preamble':
    r"""
    \usepackage{cmbright}
    \usepackage{amsmath}
    \DeclareMathOperator*{\argmin}{argmin}
    \DeclareMathOperator{\diag}{diag}
    \DeclareMathOperator{\Var}{{Var}}
    \DeclareMathOperator{\trace}{tr}
    \DeclareMathOperator{\prox}{prox}
    \DeclareMathOperator{\Rem}{Rem}
    \def\E{\mathbb{E}}
    \def\R{\mathbb{R}}
    \def\eps{\varepsilon}
    \def\df{{\hat{\mathsf{df}}}}
    \def\tdf{{\tilde{\mathsf{df}}}}
    \def\hbeta{{\hat\beta}}
    \def\hpsi{{\hat\psi}}
    \def\bA{\boldsymbol{A}}
    \def\hbA{\widehat{\boldsymbol{A}}}
    \def\bX{\boldsymbol{X}}
    \def\by{\boldsymbol{y}}
    \def\bV{\boldsymbol{V}}
    \def\br{\boldsymbol{r}}
    \def\bpsi{\psi(\br)}
    \def\bep{\boldsymbol{\varepsilon}}
    \def\bSigma{\mathbf{\Sigma}}
    \def\bbeta{\boldsymbol{\beta}}
    \def\hbbeta{\widehat{\boldsymbol{\beta}}}
    """,
}
rcParams.update(LaTeX_setup)
