"""
Provides some utility functions for e.g., 
huber's loss
"""

def huber_loss(u ,Lambda = 1):
    """
    u: float
    Lambda: parameter
    """
    return u ** 2  / 2 if abs(u) <= Lambda else Lambda * abs(u) - (1/2) * Lambda ** 2

if __name__ == "__main__":
    """
    example
    """
    import matplotlib.pyplot as plt
    from numpy import arange
    x = arange(-3, 3 , 0.1)
    y = [huber_loss(u, Lambda = 2) for u in x] 
    plt.plot(x, y)
    plt.show()
