"""
Provides heatmap figures.
    Folder: fig3
    Estimator: Huber Elastic Net
    Noise: t2
    Quantities: ALO, crit, true_error
    Setup: 2 setups, "a" and "b"
"""
import os
from heatmap_plotter import (
    HeatmapData,
    HeatmapPlotter,
    )
from numpy import (
    array, 
    mean,
    abs,
    )
from numpy.linalg import (
    norm,
    )
from linear_data_generator import LinearDataGenerator 
from huber_elasticnet_regression import (
        HuberElasticNetRegression
        )
from rich.progress import Progress
from rich import inspect
from collections import OrderedDict

class HeatmapSetup3:
    """
    Provide a heatmap setup.
    """
    def __init__(self, sample_size_per_grid=1, path='fig3/', setup='a'):
        """
        Arg
            sample_size_per_grid: number of interations each grid
            path: the folder to save the figures
            setup: either 'a' or 'b', representing different simulation setups
        """
        self.sample_size_per_grid = sample_size_per_grid
        self.path=path
        if not os.path.exists(self.path):
            os.makedirs(self.path)
        self.setup=setup

    def run(self, to_generate_data=True):
        """
        Example: Huber ElasticNet Regression
        Arg
            to_generate_data: whether or not to read from disk or to generate and write data to disk
        """
        n,p,k = 1001,1000,100
        if self.setup == 'a':
            Lambda_value = 0.054 * n ** (1/2)
            columns_value = n ** (-1/2) * array(
                [0.1 * 1.5 ** k for k in range(13)]
                )
        elif self.setup == 'b':
            Lambda_value = 0.024 * n ** (1/2)
            columns_value = n ** (-1/2) * array(
                [0.1 * 1.5 ** (k-4) for k in range(13)]
                )
        else: 
            Lambda_value = 0.054 * n ** (1/2)
            columns_value = n ** (-1/2) * array(
                [0.1 * 1.5 ** k for k in range(13)]
                )

        #
        #  Heatmap Configuration
        # 
        heatmap_config = OrderedDict({ 
            'df_over_n': {
                'title': r'$\df/n$',
                'cmap': 'Spectral',
                'vmax': 1,
                'vmin': 0,
                },
            'phat_over_n': {
                'title': r'$\hat{p}/n$',
                'cmap': 'Spectral',
                'vmax': 1,
                'vmin': 0,
                },
            'nhat_over_n': {
                'title': r'$\hat{n}/n$',
                'cmap': 'Spectral',
                'vmax': 1,
                'vmin': 0,
                },
            'df_trSigmaAtrV_diff_over_n': {
                'title': r'$|\df-\trace[\bSigma\hbA]\trace[\bV]|/n$',
                'cmap': 'Spectral',
                'vmax': 1,
                'vmin': 0,
                },
            'trSigmaA': {
                'title': r'$\trace[\bSigma\hbA]$',
                'cmap': 'nipy_spectral',
                'vmax': 6 if self.setup=='a' else 23 if self.setup=='b' else 6,
                'vmin': 0,
                },
            'trSigmaA_diff_df_over_trV': {
                'title': r'$|\trace[\bSigma\hbA]-\df/\trace[\bV]|$',
                'cmap': 'nipy_spectral',
                'vmax': 6 if self.setup=='a' else 23 if self.setup=='b' else 6,
                'vmin': 0,
                },
            'estimation_error': {
                'title': r'$\|\bSigma^{1/2}(\hbbeta-\bbeta^*)\|^2$',
                'cmap': 'terrain',
                'vmax': 12 if self.setup=='a' else 45 if self.setup=='b' else 12,
                'vmin': 0,
                },
            'ALO_minus_noise': { 
                'title': r'$|\text{ALO}-\|\bep\|^2/n|$',
                'cmap': 'terrain', 
                'vmax': 12 if self.setup=='a' else 45 if self.setup=='b' else 12,
                'vmin': 0,
                },
            'ALO_minus_noise_est_err_diff': { 
                'title': r'$|\|\bSigma^{1/2}(\hbbeta-\bbeta^*)\|^2-\text{ALO}+\|\bep\|^2/n|$',
                'cmap': 'terrain', 
                'vmax': 12 if self.setup=='a' else 45 if self.setup=='b' else 12,
                'vmin': 0,
                },
            'crit_over_n_minus_noise': {
                'title': r'$|\|\br+\frac{\df}{\trace[\bV]}\bpsi\|^2/n-\|\bep\|^2/n|$',
                'cmap': 'terrain',
                'vmax': 12 if self.setup=='a' else 45 if self.setup=='b' else 12,
                'vmin': 0,
                },
            'crit_over_n_minus_noise_est_err_diff': {
                'title': r'$|\|\bSigma^{1/2}(\hbbeta-\bbeta^*)\|^2-\|\br+\frac{\df}{\trace[\bV]}\bpsi\|^2/n+\|\bep\|^2/n|$',
                'cmap': 'terrain',
                'vmax': 12 if self.setup=='a' else 45 if self.setup=='b' else 12,
                'vmin': 0,
                },
            'unob_crit_over_n_minus_noise': {
                'title': r'$|\|\br+\trace[\bSigma\hbA]\bpsi\|^2/n-\|\bep\|^2/n|$',
                'cmap': 'terrain', 
                'vmax': 12 if self.setup=='a' else 45 if self.setup=='b' else 12,
                'vmin': 0,
                },
            'unob_crit_over_n_minus_noise_est_err_diff': {
                'title': r'$|\|\bSigma^{1/2}(\hbbeta-\bbeta^*)\|^2-\|\br+\trace[\bSigma\hbA]\bpsi\|^2/n+\|\bep\|^2/n|$',
                'cmap': 'terrain', 
                'vmax': 12 if self.setup=='a' else 45 if self.setup=='b' else 12,
                'vmin': 0,
                },
            })
        # set pdf filename by path
        for quantity_name in heatmap_config:
            heatmap_config[quantity_name]['filename'] = self.path + quantity_name + '.pdf'

        heatmap_data = HeatmapData(
            index_name = r'$\tau$',
            index = [
                10 ** (-10), 
                10 ** (-7), 
                10 ** (-5), 
                10 ** (-3), 
                10 ** (-2), 
                10 ** (-1.5), 
                10 ** (-1.2), 
                10 ** (-1),
                ],
            columns_name = r'$\lambda$',
            columns = columns_value,
            quantity_name_list = list(heatmap_config)
            )
        if to_generate_data:
            with Progress() as progress:
                task = progress.add_task(
                        "Generating heatmap data (in total)...",
                        total = len(heatmap_data.index) * len(heatmap_data.columns),
                        )
                sample_size_per_grid = self.sample_size_per_grid
                task_current_grid = progress.add_task(
                        "Generating heatmap data (for the current grid)...",
                        total = sample_size_per_grid,
                        )
                for tau in heatmap_data.index:
                    for lambda_ in heatmap_data.columns:
                        temp_data_array_dict = OrderedDict({quantity_name: [] for quantity_name in list(heatmap_config)})
                        for _ in range(sample_size_per_grid):
                            # Generate Data.
                            ldg = LinearDataGenerator(
                                    p=p, n=n, k=k,
                                )
                            huber_elastic_net = HuberElasticNetRegression(
                                    Lambda = Lambda_value,
                                    lambda_ = lambda_,
                                    tau = tau,
                                    )
                            huber_elastic_net.fit(y=ldg.y, X=ldg.X)

                            # Calculate ALO, crit, unobservable crit, Estimation Error, and many others.
                            result = huber_elastic_net.get_ALO_crit_unob_crit_and_many_others(Sigma=ldg.Sigma)
                            noise_plus_estimation_error = huber_elastic_net.get_noise_plus_estimation_error(
                                beta_hat = huber_elastic_net.coef_,
                                epsilon = ldg.epsilon,
                                beta = ldg.beta,
                                Sigma = ldg.Sigma,
                            )
                            noise = norm(ldg.epsilon) ** 2 / n
                            #
                            # Quantity Calculation 
                            #
                            tdad = temp_data_array_dict
                            tdad['df_over_n'].append(result['df/n'])
                            tdad['phat_over_n'].append(result['p_hat/n'])
                            tdad['nhat_over_n'].append(result['n_hat/n'])
                            tdad['df_trSigmaAtrV_diff_over_n'].append(result['|df-trSigmaAtrV|/n'])
                            tdad['trSigmaA'].append(result['trSigmaA'])
                            tdad['trSigmaA_diff_df_over_trV'].append(result['|trSigmaA-df/trV|'])
                            tdad['estimation_error'].append(noise_plus_estimation_error - noise)
                            tdad['ALO_minus_noise'].append(abs(result['ALO']- noise))
                            tdad['ALO_minus_noise_est_err_diff'].append(abs(noise_plus_estimation_error - result['ALO']))
                            tdad['crit_over_n_minus_noise'].append(abs(result['crit']/n - noise))
                            tdad['crit_over_n_minus_noise_est_err_diff'].append(abs(noise_plus_estimation_error - result['crit']/n))
                            tdad['unob_crit_over_n_minus_noise'].append((result['unob_crit']/n - noise))
                            tdad['unob_crit_over_n_minus_noise_est_err_diff'].append(abs(noise_plus_estimation_error-result['unob_crit']/n))
                            progress.update(task_current_grid, advance = 1)

                        progress.update(
                                task_current_grid,
                                advance = -sample_size_per_grid,
                                )

                        dataframe_dict = heatmap_data.heatmap_dataframe_dict
                        for quantity in dataframe_dict:
                            dataframe_dict[quantity].loc[tau, lambda_] = mean(tdad[quantity])
                        progress.update(task, advance = 1)
        else:
            heatmap_data.heatmap_dataframe_dict = HeatmapData.load(self.path + 'data.b')
            
        inspect(heatmap_data)
        heatmap_plotter = HeatmapPlotter(
                heatmap_data = heatmap_data,
                heatmap_config = heatmap_config
                )
        inspect(heatmap_plotter)
        heatmap_plotter.plot()
        if to_generate_data:
            heatmap_data.dump(filename=self.path + 'data.b')

if __name__ == '__main__':
    heatmap_setup_3 = HeatmapSetup3(sample_size_per_grid=1, path='fig3/1a/',setup='a')
    heatmap_setup_3.run(to_generate_data=True)
    heatmap_setup_3 = HeatmapSetup3(sample_size_per_grid=100, path='fig3/100a/',setup='a')
    heatmap_setup_3.run(to_generate_data=True)
    heatmap_setup_3 = HeatmapSetup3(sample_size_per_grid=1, path='fig3/1b/',setup='b')
    heatmap_setup_3.run(to_generate_data=True)
    heatmap_setup_3 = HeatmapSetup3(sample_size_per_grid=50, path='fig3/50b/',setup='b')
    heatmap_setup_3.run(to_generate_data=True)
