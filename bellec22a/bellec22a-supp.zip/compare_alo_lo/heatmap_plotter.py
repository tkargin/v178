"""
Provides two classes that plot heatmaps.
"""
from pickle import (
        dump,
        load,
        )
from pandas import DataFrame
from seaborn import heatmap
from matplotlib.pyplot import (
        subplots,
        close,
        tight_layout,
        )
from collections import OrderedDict
# Use LaTeX in matplotlib.
from latex_matplotlib import LaTeX_setup

class HeatmapData:
    """
    Data used to plot heatmap.
    The base class is a list of panda dataframes.

    Attributes:
        heatmap_dataframe_dict:
            A dictionary, with values a dataframe for heatmap.
    """
    def __init__(self, index_name, columns_name, index, columns, quantity_name_list):
        """
        Args:
            index_name
            columns_name
            index
            columns
            quantity_name_list
            heatmap_dataframe_dict
        """
        self.index_name = index_name
        self.columns_name = columns_name
        self.index = index
        self.columns = columns
        self.quantity_name_list = quantity_name_list
        self.heatmap_dataframe_dict = OrderedDict()
        self._initialize_heatmap_dataframe_dict()

    def _initialize_heatmap_dataframe_dict(self):
        """
        Initialize the dataframe dict.
        """
        if self.quantity_name_list is None:
            return
        for key in self.quantity_name_list:
            dataframe = DataFrame(
                    index=self.index,
                    columns=self.columns,
                    dtype='float',
                    )
            dataframe.index.name = self.index_name
            dataframe.columns.name = self.columns_name
            self.heatmap_dataframe_dict[key] = dataframe

    def dump(self, filename):
        """
        Save the data to the disk.
        """
        with open(filename, "wb") as file:
            dump(self.heatmap_dataframe_dict, file)
        print(f"The data is dumped at {filename}.")

    @classmethod
    def load(cls, filename):
        """
        Read the data from the disk.
        """
        with open(filename, "rb") as file:
            heatmap_dataframe_dict = load(file)
        print(f"The data is loaded from {filename}.")
        return heatmap_dataframe_dict

class HeatmapPlotter:
    """
    Input a HeatmapData and output a figure.
    """
    def __init__(self, heatmap_data, heatmap_config):
        """
        Arg
            heatmap_data_dataframe_dict: a dict, with quantity names, mapping to a dataframe to be plotted
            config: a dict, with quantity names, mapping to configs, including
                cmap, filename, title, vmax, vmin
        """
        self.heatmap_data_dataframe_dict = heatmap_data.heatmap_dataframe_dict
        self.config = heatmap_config

    def plot(self):
        """
        Plot multiple heatmaps from the heatmap_data.
        """
        dataframe_dict = self.heatmap_data_dataframe_dict
        config = self.config

        for _, dataframe_name in enumerate(dataframe_dict):
            self._plot_dataframe(
                    cmap=config[dataframe_name]['cmap'],
                    dataframe=dataframe_dict[dataframe_name],
                    filename=config[dataframe_name]['filename'],
                    title=config[dataframe_name]['title'],
                    vmax=config[dataframe_name]['vmax'],
                    vmin=config[dataframe_name]['vmin'],
                )

    @staticmethod
    def _plot_dataframe(dataframe, title, filename, vmin, vmax, cmap='terrain', annot=False):
        """
        Args:
            filename: String. Example of filename xxx.pdf.
        """
        fig, ax = subplots(
                figsize=(11, 8.5),
                )
        tight_layout(pad=7)
        heatmap(
                data=dataframe,
                ax=ax,
                cmap=cmap,
                annot=annot,
                vmin=vmin,
                vmax=vmax,
                )
        # >>>>> More Style Options {{{1
        # title {{{2
        ax.set_title(label=title, fontsize=22)
        # tick labels {{{2
        xticklabels = [
            f"{float(x.get_text()):.2g}" for x in ax.get_xticklabels()]
        yticklabels = [
            f"{float(y.get_text()):.2g}" for y in ax.get_yticklabels()]
        ax.set_xticklabels(xticklabels, fontsize=30)
        ax.set_yticklabels(yticklabels, fontsize=30)

        # labels {{{2
        ax.set_xlabel(ax.get_xlabel(), fontsize=30)
        ax.set_ylabel(ax.get_ylabel(), fontsize=30)

        # color bar {{{2
        cbar = ax.collections[0].colorbar
        cbar.ax.tick_params(labelsize=20)

        # tick parameter {{{2
        ax.tick_params(labelsize = 20)
        # }}}2

        # Save figures.
        fig.savefig(
                fname=filename,
                dpi=300,
                )
        # }}}1
        print(f'The figure {filename} has been exported.')
        close()

if __name__ == "__main__":
    """
    Example: Linear Huber ElasticNet Regression
    """
    from numpy import array
    n = 1000
    p = 1001
    heatmap_data = HeatmapData(
        index_name = r'$\tau$',
        index = [
            10 ** (-10),
            10 ** (-7),
            10 ** (-5),
            10 ** (-3),
            10 ** (-2),
            10 ** (-1.5),
            10 ** (-1.2),
            10 ** (-1),
            ],
        columns_name = r'$\lambda$',
        columns = n ** (-1/2) * array(
            [0.1 * 1.5 ** k for k in range(13)]
            ),
        quantity_name_list = ['ALO', 'LO', 'crit']
            )

    from numpy.random import randn
    for tau in heatmap_data.index:
        for lambda_ in heatmap_data.columns:
            dataframe_dict = heatmap_data.heatmap_dataframe_dict
            dataframe_dict['ALO'].loc[tau, lambda_] = randn()
            dataframe_dict['LO'].loc[tau, lambda_] = randn()
            dataframe_dict['crit'].loc[tau, lambda_] = randn()

    from rich import inspect
    inspect(heatmap_data)

    heatmap_plotter = HeatmapPlotter(
            heatmap_data = heatmap_data,
            heatmap_config = OrderedDict({
                'ALO': {
                    'cmap': 'terrain',
                    'title': 'ALO',
                    'filename': 'ALO.pdf',
                    'vmin': None,
                    'vmax': None,
                    },
                'LO': {
                    'cmap': 'terrain',
                    'title': 'LO',
                    'filename': 'LO.pdf',
                    'vmin': None,
                    'vmax': None,
                    },
                'crit': {
                    'cmap': 'terrain',
                    'title': 'crit',
                    'filename': 'crit.pdf',
                    'vmin': None,
                    'vmax': None,
                    },
                })
            )

    inspect(heatmap_plotter)
    heatmap_plotter.plot()

    ##### 
    #
    # Example for dumping and loading the dataset.
    #
    #####
    heatmap_data = HeatmapData(
        index_name = r'$\tau$',
        index = [
            10 ** (-10),
            10 ** (-7),
            ],
        columns_name = r'$\lambda$',
        columns = 1000 ** (-1/2) * array(
            [0.1 * 1.5 ** k for k in range(2)]
            ),
        quantity_name_list = ['ALO', 'LO', 'crit']
            )
    for tau in heatmap_data.index:
        for lambda_ in heatmap_data.columns:
            dataframe_dict = heatmap_data.heatmap_dataframe_dict
            dataframe_dict['ALO'].loc[tau, lambda_] = 1
            dataframe_dict['LO'].loc[tau, lambda_] = 1
            dataframe_dict['crit'].loc[tau, lambda_] = 1
    inspect(heatmap_data)

    heatmap_data.dump(filename='testing_data.b')

    heatmap_data = HeatmapData(
        index_name = None,
        index = None,
        columns_name = None,
        columns = None,
        quantity_name_list = None,
            )
    inspect(heatmap_data)

    # test load function
    heatmap_data = HeatmapData.load(filename='testing_data.b')
    inspect(heatmap_data)
